﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightApi.Services
{
    public class DataService
    {
        private string FlightName { get; set; }
        public void SetName(string name)
        {
            this.FlightName = name;
        }

        public string GetName()
        {
            return this.FlightName;
        }
    }
}

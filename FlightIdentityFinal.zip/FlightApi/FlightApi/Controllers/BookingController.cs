﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightApi.Models;
using FlightApi.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        //private DataService _service;
        //private IMemoryCache _memoryCache;
        //private IDistributedCache distributedCache;

        private IRepository<Booking> repository;
        public BookingController(IRepository<Booking> repo)
        {
            this.repository = repo;
        }

        //GET /api/Bookings
        [ProducesResponseType(200)]
        [HttpGet("", Name = "ListBooking")]
        public IEnumerable<Booking> GetBooking()
        {
            return this.repository.GetAll();
        }

        //GET /api/Booking/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(200)]
        [HttpGet("{id:int}", Name = "GetBooking")]
        public async Task<ActionResult<Booking>> GetBookingById(int id)
        {
            var item = await this.repository.GetByIdAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            else
            {
                return item;
            }
        }



        //POST /api/Booking
        /// <summary>
        /// Adds a new Booking to the Booking database
        /// </summary>
        /// <remarks>
        /// POST /api/Booking
        /// Sample data
        /// {
        ///     "id": 0,
        ///     "date": "2018-10-13T09:58:11.284Z",
        ///     "status": "string",
        ///     "ticketType": "string",
        ///     "fK_PK_PaymentId": "string",
        ///     "fK_PK_FlightId": "string",
        ///     "fK_PK_PassengerId": "string",
        ///     "travelDate": "string"
        ///}
        /// </remarks>
        /// <param name="Booking"></param>
        /// <returns>Newly created Booking entry</returns>
        /// <response code="201">New Booking entry is created</response>
        /// <response code="400">If invalid Booking entry object</response>
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [HttpPost("", Name = "AddBooking")]
        public async Task<ActionResult<Booking>> AddBooking(Booking Booking)
        {
            if (Booking == null)
            {
                return BadRequest();
            }
            var result = await this.repository.AddAsync(Booking);
            return CreatedAtAction("GetBookingById", new { id = result.Id }, result);
        }


        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpPut("{id:int?}", Name = "UpdateBooking")]
        public async Task<ActionResult<Booking>> UpdateBooking(int? id, Booking Booking)
        {
            if (id == null) return BadRequest();
            if (id.Value != Booking.Id) return NotFound();
            var item = await this.repository.UpdateAsync(id.Value, Booking);
            if (item == null)
                return NotFound();
            return item;
        }

        //DELETE /api/blogs/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpDelete("{id:int?}", Name = "DeleteBooking")]
        public async Task<ActionResult<Booking>> DeleteBooking(int? id)
        {
            if (id == null) return BadRequest();
            var result = await this.repository.DeleteAsync(id.Value);
            if (result == null)
            {
                return NotFound();
            }
            return result;
        }
    }
}
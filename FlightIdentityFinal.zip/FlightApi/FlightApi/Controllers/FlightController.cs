﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightApi.Models;
using FlightApi.Repositories;
using FlightApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;

namespace FlightApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightController : ControllerBase
    {
        //private DataService _service;
        //private IMemoryCache _memoryCache;
        //private IDistributedCache distributedCache;

        private IRepository<Flight> repository;
        public FlightController(IRepository<Flight> repo)
        {
            this.repository = repo;
        }

        //GET /api/flights
        [ProducesResponseType(200)]
        [HttpGet("",Name ="ListFlights")]
        public IEnumerable<Flight> GetFlights()
        {
            return this.repository.GetAll();
        }

        //GET /api/flight/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(200)]
        [HttpGet("{id:int}",Name ="GetFlight")]
        public async Task<ActionResult<Flight>> GetFlightById(int id)
        {
            var item = await this.repository.GetByIdAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            else
            {
                return item;
            }
        }

        //GET /api/flight/{fromlocation}/{tolocation}
        [ProducesResponseType(200)]
        [HttpGet("Location/{fromlocation?}/{tolocation?}", Name = "GetFlightByLocation")]
        public IEnumerable<Flight> GetFlightByLocation(string fromlocation =null,string tolocation = null)
        {
            var item = this.repository.GetAll();
            if(fromlocation != null)
            {
                item = item.Where(a => a.Source == fromlocation);
            }
            if (tolocation != null)
            {
                item = item.Where(a => a.Destination == tolocation);
            }
            return item;
        }
        //GET /api/flight/{fleettype}
        [ProducesResponseType(200)]
        [HttpGet("Fleet/{fleettype?}", Name = "GetFlightByType")]
        public IEnumerable<Flight> GetFlightByType(string fleettype =null)
        {
            var item = this.repository.GetAll();
            if (fleettype != "")
            {
                item = item.Where(a => a.FleetType == fleettype);
            }
            return item;
        }

        //GET /api/flight/{date}
        [ProducesResponseType(200)]
        [HttpGet("Flight/{date}", Name = "GetFlightByDate")]
        public IEnumerable<Flight> GetFlightByLocation(string date)
        {
            return this.repository.GetAll();
        }

        //POST /api/flight
        /// <summary>
        /// Adds a new flight to the flight database
        /// </summary>
        /// <remarks>
        /// POST /api/flight
        /// Sample data
        /// {
        ///     "FlightName":"Air India 1564",
        ///     "Source": "Chennai",
        ///     "Destination": "Delhi",
        ///     "Duration": "2 Hours"
        /// }
        /// </remarks>
        /// <param name="flight"></param>
        /// <returns>Newly created flight entry</returns>
        /// <response code="201">New flight entry is created</response>
        /// <response code="400">If invalid flight entry object</response>
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [HttpPost("",Name ="AddFlight")]
        public async Task<ActionResult<Flight>> AddFlight(Flight flight)
        {
            if(flight == null)
            {
                return BadRequest();
            }
            var result = await this.repository.AddAsync(flight);
            return CreatedAtAction("GetFlightById", new { id = result.Id },result);
        }


        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpPut("{id:int?}",Name ="UpdateFlight")]
        public async Task<ActionResult<Flight>> UpdateFlight(int?id,Flight flight)
        {
            if (id == null) return BadRequest();
            if (id.Value != flight.Id) return NotFound();
            var item = await this.repository.UpdateAsync(id.Value, flight);
            if (item == null)
                return NotFound();
            return item;
        }

        //DELETE /api/blogs/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpDelete("{id:int?}", Name = "DeleteFlight")]
        public async Task<ActionResult<Flight>> DeleteFlight(int? id)
        {
            if (id == null) return BadRequest();
            var result = await this.repository.DeleteAsync(id.Value);
            if(result == null)
            {
                return NotFound();
            }
            return result;
        }
    }
}
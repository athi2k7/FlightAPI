﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightApi.Models;
using FlightApi.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PassengerController : ControllerBase
    {
        //private DataService _service;
        //private IMemoryCache _memoryCache;
        //private IDistributedCache distributedCache;

        private IRepository<Passenger> repository;
        public PassengerController(IRepository<Passenger> repo)
        {
            this.repository = repo;
        }

        //GET /api/passengers
        [ProducesResponseType(200)]
        [HttpGet("", Name = "ListPassenger")]
        public IEnumerable<Passenger> GetPassenger()
        {
            return this.repository.GetAll();
        }

        //GET /api/passenger/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(200)]
        [HttpGet("{id:int}", Name = "GetPassenger")]
        public async Task<ActionResult<Passenger>> GetPassengerById(int id)
        {
            var item = await this.repository.GetByIdAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            else
            {
                return item;
            }
        }



        //POST /api/passenger
        /// <summary>
        /// Adds a new passenger to the passenger database
        /// </summary>
        /// <remarks>
        /// POST /api/passenger
        /// Sample data
        /// {
        ///     "FirstName":"Tony",
        ///     "LastName":"Stark",
        ///     "PhoneNumber": "001-123456789",
        ///     "EmailAddress": "TonyStark@Avengers.com",
        ///     "Address": "5, Stark Tower, NY",
        ///     "City": "Newyork"
        /// }
        /// </remarks>
        /// <param name="passenger"></param>
        /// <returns>Newly created passenger entry</returns>
        /// <response code="201">New passenger entry is created</response>
        /// <response code="400">If invalid passenger entry object</response>
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [HttpPost("", Name = "AddPassenger")]
        public async Task<ActionResult<Passenger>> AddPassenger(Passenger passenger)
        {
            if (passenger == null)
            {
                return BadRequest();
            }
            var result = await this.repository.AddAsync(passenger);
            return CreatedAtAction("GetPassengerById", new { id = result.Id }, result);
        }


        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpPut("{id:int?}", Name = "UpdatePassenger")]
        public async Task<ActionResult<Passenger>> UpdatePassenger(int? id, Passenger passenger)
        {
            if (id == null) return BadRequest();
            if (id.Value != passenger.Id) return NotFound();
            var item = await this.repository.UpdateAsync(id.Value, passenger);
            if (item == null)
                return NotFound();
            return item;
        }

        //DELETE /api/blogs/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpDelete("{id:int?}", Name = "DeletePassenger")]
        public async Task<ActionResult<Passenger>> DeletePassenger(int? id)
        {
            if (id == null) return BadRequest();
            var result = await this.repository.DeleteAsync(id.Value);
            if (result == null)
            {
                return NotFound();
            }
            return result;
        }
    }
}
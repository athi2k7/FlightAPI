﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightApi.Models;
using FlightApi.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        //private DataService _service;
        //private IMemoryCache _memoryCache;
        //private IDistributedCache distributedCache;

        private IRepository<Payment> repository;
        public PaymentController(IRepository<Payment> repo)
        {
            this.repository = repo;
        }

        //GET /api/Payments
        [ProducesResponseType(200)]
        [HttpGet("", Name = "ListPayment")]
        public IEnumerable<Payment> GetPayment()
        {
            return this.repository.GetAll();
        }

        //GET /api/Payment/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(200)]
        [HttpGet("{id:int}", Name = "GetPayment")]
        public async Task<ActionResult<Payment>> GetPaymentById(int id)
        {
            var item = await this.repository.GetByIdAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            else
            {
                return item;
            }
        }



        //POST /api/Payment
        /// <summary>
        /// Adds a new Payment to the Payment database
        /// </summary>
        /// <remarks>
        /// POST /api/Payment
        /// Sample data
        /// {
        ///     "FirstName":"Tony",
        ///     "LastName":"Stark",
        ///     "PhoneNumber": "001-123456789",
        ///     "EmailAddress": "TonyStark@Avengers.com",
        ///     "Address": "5, Stark Tower, NY",
        ///     "City": "Newyork"
        /// }
        /// </remarks>
        /// <param name="Payment"></param>
        /// <returns>Newly created Payment entry</returns>
        /// <response code="201">New Payment entry is created</response>
        /// <response code="400">If invalid Payment entry object</response>
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [HttpPost("", Name = "AddPayment")]
        public async Task<ActionResult<Payment>> AddPayment(Payment Payment)
        {
            if (Payment == null)
            {
                return BadRequest();
            }
            var result = await this.repository.AddAsync(Payment);
            return CreatedAtAction("GetPaymentById", new { id = result.Id }, result);
        }


        //[ProducesResponseType(400)]
        //[ProducesResponseType(404)]
        //[ProducesResponseType(200)]
        //[HttpPut("{id:int?}", Name = "UpdatePayment")]
        //public async Task<ActionResult<Payment>> UpdatePayment(int? id, Payment Payment)
        //{
        //    if (id == null) return BadRequest();
        //    if (id.Value != Payment.Id) return NotFound();
        //    var item = await this.repository.UpdateAsync(id.Value, Payment);
        //    if (item == null)
        //        return NotFound();
        //    return item;
        //}

        ////DELETE /api/blogs/{id}
        //[ProducesResponseType(400)]
        //[ProducesResponseType(404)]
        //[ProducesResponseType(200)]
        //[HttpDelete("{id:int?}", Name = "DeletePayment")]
        //public async Task<ActionResult<Payment>> DeletePayment(int? id)
        //{
        //    if (id == null) return BadRequest();
        //    var result = await this.repository.DeleteAsync(id.Value);
        //    if (result == null)
        //    {
        //        return NotFound();
        //    }
        //    return result;
        //}
    }
}
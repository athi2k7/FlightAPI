﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using FlightApi.Infrastructure;
using FlightApi.Models;
using FlightApi.Repositories;
using FlightApi.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Swashbuckle.AspNetCore.Swagger;

namespace FlightApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddDefaultPolicy(policy =>
                {
                    policy
                    .AllowAnyOrigin()
                    .AllowAnyHeader()
                    .AllowAnyHeader();
                });
            });

            //services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            //    .AddIdentityServerAuthentication(options =>
            //    {
            //        options.Authority = Configuration.GetValue<string>("IdentityServerUrl");
            //        options.RequireHttpsMetadata = false;
            //        options.ApiName = "FlightAPI";
            //    });

            #region added sql server
            services.AddDbContext<FlightContext>(options =>
            {
                options.UseSqlServer(Configuration.GetValue<string>("ConnectionString"));
            });
            #endregion

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Info
                {
                    Title = "Flight API",
                    Version = "v1",
                    Contact = new Contact
                    {
                        Name = "Prakash Kumar",
                        Email = "PrakashK@hexaware.com",
                        Url = "https://www.hexaware.com"
                    },
                    Description = "Flight API to search flight",
                    TermsOfService = string.Empty,
                    License = new License { Name = "MIT License", Url = "https://www.hexaware.com/about" }
                });
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                options.IncludeXmlComments(xmlPath);
            });

            #region Redis
            //services.AddDistributedMemoryCache();
            //services.AddSession(options =>
            //{
            //    options.Cookie = new CookieBuilder
            //    {
            //        Name = "SESSION_COOKIE",
            //        Expiration = TimeSpan.FromMinutes(10)
            //    };
            //    options.IdleTimeout = TimeSpan.FromMinutes(2);
            //});

            //services.AddResponseCaching();
            //services.AddMemoryCache();
            //services.AddDistributedRedisCache(options=>
            //{
            //    options.InstanceName = Configuration.GetValue<string>("redis:name");
            //    options.Configuration= Configuration.GetValue<string>("redis:server");
            //});


            //services.AddSingleton<DataService>();

            #endregion

            services.AddScoped<IRepository<Flight>, Repository<Flight>>();
            services.AddScoped<IRepository<Passenger>, Repository<Passenger>>();
            services.AddScoped<IRepository<Payment>, Repository<Payment>>();
            services.AddScoped<IRepository<Booking>, Repository<Booking>>();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1)
                .AddSessionStateTempDataProvider();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler(options =>
                {
                    options.Run(async (context) =>
                    {
                        context.Response.StatusCode = 500;
                        var msg = "Some type of error occured in the server";
                        await context.Response.WriteAsync(msg);
                    });
                });
            }
            InitializeDatabase(app);
            app.UseStaticFiles();
            app.UseAuthentication();
            app.UseCors();
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "Flight API");
                options.RoutePrefix = string.Empty;
            });

            

            app.UseMvc();
        }
        private void InitializeDatabase(IApplicationBuilder app)
        {
            using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                serviceScope.ServiceProvider.GetRequiredService<FlightContext>().Database.Migrate();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FlightApi.Models
{
    public class Booking : EntityBase
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public override int Id { get; set; }
        [Required]
        [DataType(DataType.DateTime)]
        public string Date { get; set; }
        [Required]
        public string Status { get; set; }
        [Required]
        public string TicketType{ get; set; }
        [Required]
        public string FK_PK_PaymentId { get; set; }
        [Required]
        public string FK_PK_FlightId { get; set; }

        [Required]
        public string FK_PK_PassengerId { get; set; }

        [Required]
        public string TravelDate { get; set; }
    }
}

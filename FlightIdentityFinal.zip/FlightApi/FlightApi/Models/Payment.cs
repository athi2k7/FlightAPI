﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FlightApi.Models
{
    public class Payment : EntityBase
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public override int Id { get; set; }
        [Required]
        public string Amount { get; set; }
        [Required]
        public string Date { get; set; }
        [Required]
        public string Type{ get; set; }
        [Required]
        public string Tax { get; set; }
        [Required]
        public string ServiceCharge { get; set; }
    }
}

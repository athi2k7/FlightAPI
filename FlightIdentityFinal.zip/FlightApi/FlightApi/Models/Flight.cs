﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FlightApi.Models
{
    public class Flight : EntityBase
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public override int Id { get; set; }
        [Required]
        public string FlightName { get; set; }
        [Required]
        public string FleetType { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        [Required]
        public string Duration { get; set; }
    }
}

﻿using FlightApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightApi.Infrastructure
{
    public class FlightContext :DbContext
    {
        public FlightContext(DbContextOptions options): base(options)
        {

        }

        public DbSet<Flight> Flights{ get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Passenger> Passengers { get; set; }
    }
}
